<h5 class="qodef-ci-title">
    <a href="<?php echo get_permalink($id); ?>" target="<?php echo esc_attr( "_self" ); ?>">
        <?php echo esc_html( get_the_title($id) ); ?>
    </a>
</h5>