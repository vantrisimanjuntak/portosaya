<?php
require_once 'property-large-slider.php';
require_once 'helper-functions.php';