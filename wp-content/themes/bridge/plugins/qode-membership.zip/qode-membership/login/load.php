<?php
require_once 'common.php';
require_once 'facebook-login.php';
require_once 'google-login.php';
require_once 'wordpress-login.php';