<a href="javascript:void(0)" class="qodef-membership-item-favorites" data-item-id="<?php echo esc_attr($item_id); ?>">
    <i class="qodef-favorites-icon fa <?php echo esc_attr( $icon ); ?>"></i>
    <span class="qodef-favorites-text">
        <?php echo esc_attr( $favorites_text ); ?>
    </span>
</a>
