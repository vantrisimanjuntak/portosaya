<?php if($query_result->max_num_pages > 1) { ?>
	<div class="qode-news-pag-loading">
		<div class="qode-news-pag-bounce1"></div>
		<div class="qode-news-pag-bounce2"></div>
		<div class="qode-news-pag-bounce3"></div>
	</div>
<?php }