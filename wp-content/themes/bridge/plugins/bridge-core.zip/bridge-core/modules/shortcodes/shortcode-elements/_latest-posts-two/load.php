<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_latest-posts-two/latest-posts-two.php';
