<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_social-icons/social-icons.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_social-icons/custom-styles/custom-styles.php';
