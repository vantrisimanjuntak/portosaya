<?php return array('dependencies' => array(), 'version' => '7490e9794bdbcf3a1374');
