<?php return array('dependencies' => array(), 'version' => '27be0e10166a8144ec05');
